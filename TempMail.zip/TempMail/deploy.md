# Deploy Quickiemail to abearinthere.com

## Your app is ready! Here's how to deploy it:

### Method 1: Use Vercel (Recommended)

1. **Go to [vercel.com](https://vercel.com)** and sign up with GitHub
2. **Import your project**:
   - Download your Replit project as ZIP
   - Upload to GitHub or import directly to Vercel
3. **Configure deployment**:
   - Build Command: `npm run build`
   - Output Directory: `dist/public`
   - Install Command: `npm install`
4. **Add environment variables**:
   ```
   STRIPE_SECRET_KEY_NEW=sk_live_...
   VITE_STRIPE_PUBLIC_KEY_NEW=pk_live_...
   ```
5. **Deploy** - You'll get a vercel.app URL
6. **Add custom domain**:
   - Go to Project Settings → Domains
   - Add `abearinthere.com`
   - Update your DNS with the CNAME record provided

### Method 2: Use Netlify

1. **Go to [netlify.com](https://netlify.com)**
2. **Drag & drop** your project folder
3. **Configure**:
   - Build command: `npm run build`
   - Publish directory: `dist/public`
4. **Add environment variables** in Site Settings
5. **Add custom domain** in Domain Management

### DNS Setup for abearinthere.com

In your domain registrar:
1. **Add CNAME record**:
   - Name: `@` (or `www`)
   - Target: `your-deployment-url` (from Vercel/Netlify)
2. **Save** and wait 1-24 hours for propagation

### Files Ready for Deployment:
✓ Google AdSense integrated (ca-pub-6007363543206285)
✓ Privacy Policy & Terms of Service pages
✓ Stripe payment system ($2.99 premium)
✓ Email forwarding & temporary emails
✓ Responsive design
✓ Build configuration ready

Your site will be live at abearinthere.com once DNS propagates!