# Quickiemail - Temporary Email Service

## Overview

Quickiemail is a temporary email service application built with a full-stack JavaScript architecture. The application allows users to generate temporary email addresses that expire after a set time period, with premium options for extended duration. Users can receive emails at these temporary addresses, view them in an inbox interface, and forward emails to their real email addresses.

## System Architecture

### Frontend Architecture
- **Framework**: React 18+ with TypeScript
- **Build Tool**: Vite for development and production builds
- **UI Library**: Radix UI components with shadcn/ui styling system
- **Styling**: Tailwind CSS with custom design tokens and CSS variables
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Payment Integration**: Stripe for premium upgrade payments

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **Development**: Hot reload via Vite middleware in development mode
- **API Design**: RESTful API endpoints with JSON communication
- **Error Handling**: Centralized error middleware with structured error responses

### Data Storage Solutions
- **Database**: PostgreSQL with Neon serverless database
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema**: Centralized schema definitions in shared directory
- **Migration**: Drizzle Kit for database migrations and schema management

## Key Components

### Database Schema
The application uses four main tables:
- **users**: User accounts with Stripe integration fields
- **temporaryEmails**: Generated temporary email addresses with expiration times
- **emailMessages**: Received emails linked to temporary addresses
- **emailForwards**: Records of forwarded emails with recipient information

### Email Management System
- **Email Generation**: Creates unique temporary email addresses with configurable expiration
- **Email Reception**: Handles incoming emails to temporary addresses
- **Email Forwarding**: Allows users to forward received emails to personal addresses
- **Premium Features**: Extended 24-hour duration for premium users

### Payment Integration
- **Stripe Integration**: Handles premium upgrade payments
- **Subscription Management**: Tracks customer and subscription information
- **Checkout Flow**: Dedicated checkout page with Stripe Elements

### User Interface Components
- **Email Generator**: Creates and manages temporary email addresses
- **Inbox**: Displays received emails with real-time updates
- **Timer Component**: Shows remaining time for email expiration
- **Premium Modal**: Upgrade interface for premium features
- **Forward Modal**: Email forwarding interface

## Data Flow

1. **Email Generation**: User requests temporary email → Server generates unique address → Database stores with expiration
2. **Email Reception**: External email arrives → Server processes → Stores in database → Client polls for updates
3. **Premium Upgrade**: User initiates upgrade → Stripe checkout → Payment processing → Database upgrade → Extended expiration
4. **Email Forwarding**: User selects email → Enters recipient → Server forwards email → Records forward action

## External Dependencies

### Payment Processing
- **Stripe**: Handles all payment processing and subscription management
- **Environment Variables**: STRIPE_SECRET_KEY and VITE_STRIPE_PUBLIC_KEY required

### Database
- **Neon PostgreSQL**: Serverless PostgreSQL database for production
- **Connection**: Uses @neondatabase/serverless driver
- **Environment Variable**: DATABASE_URL required for connection

### Development Tools
- **Replit Integration**: Cartographer plugin for development environment
- **Runtime Error Overlay**: Enhanced error reporting in development

## Deployment Strategy

### Build Process
- **Client Build**: Vite builds React application to `dist/public`
- **Server Build**: esbuild bundles Express server to `dist/index.js`
- **Static Assets**: Client assets served from Express in production

### Environment Configuration
- **Development**: Uses Vite dev server with Express API proxy
- **Production**: Express serves static files and API endpoints
- **Environment Variables**: Required for database connection and Stripe integration

### Database Management
- **Schema Deployment**: `npm run db:push` applies schema changes
- **Migration System**: Drizzle Kit manages database migrations
- **Connection Pooling**: Uses serverless-friendly connection handling

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

- July 02, 2025: Initial Quickiemail setup with full functionality
- July 02, 2025: Added Stripe payment integration for premium upgrades ($2.99)
- July 02, 2025: Implemented Google AdSense integration with placeholder ads
- July 02, 2025: Added demo email functionality for testing inbox features
- July 02, 2025: Enhanced UI with responsive design and professional footer
- July 02, 2025: Added SEO optimization with meta tags and Open Graph support
- July 02, 2025: Implemented timer component showing remaining email duration
- July 02, 2025: Added email forwarding capability with modal interface
- July 02, 2025: Fixed premium upgrade system with robust server restart handling
- July 02, 2025: Resolved Stripe API key corruption with fresh key implementation
- July 02, 2025: Added localStorage persistence and validation for email data
- July 02, 2025: Implemented fallback upgrade logic using email address metadata
- July 02, 2025: Updated Google AdSense integration with live publisher ID (ca-pub-6007363543206285)

## Changelog

Changelog:
- July 02, 2025: Complete Quickiemail application with premium features and monetization