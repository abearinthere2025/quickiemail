import { 
  users, 
  temporaryEmails, 
  emailMessages, 
  emailForwards,
  type User, 
  type InsertUser,
  type TemporaryEmail,
  type InsertTemporaryEmail,
  type EmailMessage,
  type InsertEmailMessage,
  type EmailForward,
  type InsertEmailForward
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStripeInfo(id: number, stripeCustomerId: string, stripeSubscriptionId?: string): Promise<User>;
  
  // Temporary Emails
  createTemporaryEmail(email: InsertTemporaryEmail): Promise<TemporaryEmail>;
  getTemporaryEmail(emailAddress: string): Promise<TemporaryEmail | undefined>;
  getTemporaryEmailById(id: number): Promise<TemporaryEmail | undefined>;
  updateTemporaryEmailExpiry(id: number, expiresAt: Date): Promise<TemporaryEmail>;
  upgradeToPremium(id: number): Promise<TemporaryEmail>;
  deleteExpiredEmails(): Promise<void>;
  
  // Email Messages
  createEmailMessage(message: InsertEmailMessage): Promise<EmailMessage>;
  getEmailMessages(temporaryEmailId: number): Promise<EmailMessage[]>;
  markEmailAsRead(messageId: number): Promise<EmailMessage>;
  
  // Email Forwards
  createEmailForward(forward: InsertEmailForward): Promise<EmailForward>;
  getEmailForwards(messageId: number): Promise<EmailForward[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private temporaryEmails: Map<number, TemporaryEmail>;
  private emailMessages: Map<number, EmailMessage>;
  private emailForwards: Map<number, EmailForward>;
  private currentUserId: number;
  private currentEmailId: number;
  private currentMessageId: number;
  private currentForwardId: number;

  constructor() {
    this.users = new Map();
    this.temporaryEmails = new Map();
    this.emailMessages = new Map();
    this.emailForwards = new Map();
    this.currentUserId = 1;
    this.currentEmailId = 1;
    this.currentMessageId = 1;
    this.currentForwardId = 1;
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id, stripeCustomerId: null, stripeSubscriptionId: null };
    this.users.set(id, user);
    return user;
  }

  async updateUserStripeInfo(id: number, stripeCustomerId: string, stripeSubscriptionId?: string): Promise<User> {
    const user = this.users.get(id);
    if (!user) throw new Error("User not found");
    
    const updatedUser = { ...user, stripeCustomerId, stripeSubscriptionId: stripeSubscriptionId || null };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Temporary Emails
  async createTemporaryEmail(insertEmail: InsertTemporaryEmail): Promise<TemporaryEmail> {
    // Check if an email with this address already exists (handle server restart scenarios)
    const existingEmail = await this.getTemporaryEmail(insertEmail.emailAddress);
    if (existingEmail) {
      return existingEmail;
    }
    
    const id = this.currentEmailId++;
    const email: TemporaryEmail = { 
      ...insertEmail,
      id, 
      createdAt: new Date(),
      isPremium: insertEmail.isPremium ?? false
    };
    this.temporaryEmails.set(id, email);
    return email;
  }

  async getTemporaryEmail(emailAddress: string): Promise<TemporaryEmail | undefined> {
    return Array.from(this.temporaryEmails.values()).find(email => email.emailAddress === emailAddress);
  }

  async getTemporaryEmailById(id: number): Promise<TemporaryEmail | undefined> {
    return this.temporaryEmails.get(id);
  }

  async updateTemporaryEmailExpiry(id: number, expiresAt: Date): Promise<TemporaryEmail> {
    const email = this.temporaryEmails.get(id);
    if (!email) throw new Error("Email not found");
    
    const updatedEmail = { ...email, expiresAt };
    this.temporaryEmails.set(id, updatedEmail);
    return updatedEmail;
  }

  async upgradeToPremium(id: number): Promise<TemporaryEmail> {
    const email = this.temporaryEmails.get(id);
    if (!email) throw new Error("Email not found");
    
    const premiumExpiry = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
    const updatedEmail = { ...email, isPremium: true, expiresAt: premiumExpiry };
    this.temporaryEmails.set(id, updatedEmail);
    return updatedEmail;
  }

  async deleteExpiredEmails(): Promise<void> {
    const now = new Date();
    Array.from(this.temporaryEmails.entries()).forEach(([id, email]) => {
      if (email.expiresAt < now) {
        this.temporaryEmails.delete(id);
        // Also delete associated messages
        Array.from(this.emailMessages.entries()).forEach(([msgId, message]) => {
          if (message.temporaryEmailId === id) {
            this.emailMessages.delete(msgId);
          }
        });
      }
    });
  }

  // Email Messages
  async createEmailMessage(insertMessage: InsertEmailMessage): Promise<EmailMessage> {
    const id = this.currentMessageId++;
    const message: EmailMessage = { 
      ...insertMessage,
      id, 
      receivedAt: new Date(),
      isRead: false,
      temporaryEmailId: insertMessage.temporaryEmailId ?? null
    };
    this.emailMessages.set(id, message);
    return message;
  }

  async getEmailMessages(temporaryEmailId: number): Promise<EmailMessage[]> {
    return Array.from(this.emailMessages.values())
      .filter(message => message.temporaryEmailId === temporaryEmailId)
      .sort((a, b) => (b.receivedAt?.getTime() || 0) - (a.receivedAt?.getTime() || 0));
  }

  async markEmailAsRead(messageId: number): Promise<EmailMessage> {
    const message = this.emailMessages.get(messageId);
    if (!message) throw new Error("Message not found");
    
    const updatedMessage = { ...message, isRead: true };
    this.emailMessages.set(messageId, updatedMessage);
    return updatedMessage;
  }

  // Email Forwards
  async createEmailForward(insertForward: InsertEmailForward): Promise<EmailForward> {
    const id = this.currentForwardId++;
    const forward: EmailForward = { 
      ...insertForward,
      id, 
      forwardedAt: new Date(),
      messageId: insertForward.messageId ?? null,
      note: insertForward.note ?? null
    };
    this.emailForwards.set(id, forward);
    return forward;
  }

  async getEmailForwards(messageId: number): Promise<EmailForward[]> {
    return Array.from(this.emailForwards.values())
      .filter(forward => forward.messageId === messageId);
  }
}

export const storage = new MemStorage();
