import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { insertTemporaryEmailSchema, insertEmailMessageSchema, insertEmailForwardSchema } from "@shared/schema";
import { z } from "zod";

// Use fresh secret key or fallback to original
const stripeSecretKey = process.env.STRIPE_SECRET_KEY_NEW || process.env.STRIPE_SECRET_KEY;
if (!stripeSecretKey) {
  throw new Error('Missing required Stripe secret key');
}

const stripe = new Stripe(stripeSecretKey, {
  apiVersion: "2025-06-30.basil",
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Generate temporary email
  app.post("/api/generate-email", async (req, res) => {
    try {
      const emailAddress = `temp.${Math.random().toString(36).substring(2)}.${Date.now()}@quickiemail.com`;
      const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes
      
      const temporaryEmail = await storage.createTemporaryEmail({
        emailAddress,
        expiresAt,
        isPremium: false,
      });
      
      res.json(temporaryEmail);
    } catch (error: any) {
      res.status(500).json({ message: "Error generating email: " + error.message });
    }
  });

  // Get temporary email details
  app.get("/api/email/:emailAddress", async (req, res) => {
    try {
      const { emailAddress } = req.params;
      const email = await storage.getTemporaryEmail(emailAddress);
      
      if (!email) {
        return res.status(404).json({ message: "Email not found" });
      }
      
      // Check if expired
      if (email.expiresAt < new Date()) {
        return res.status(410).json({ message: "Email expired" });
      }
      
      res.json(email);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching email: " + error.message });
    }
  });

  // Extend email time (free 15 minutes)
  app.post("/api/extend-email/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const email = await storage.getTemporaryEmailById(parseInt(id));
      
      if (!email) {
        return res.status(404).json({ message: "Email not found" });
      }
      
      if (email.expiresAt < new Date()) {
        return res.status(410).json({ message: "Email expired" });
      }
      
      const newExpiryTime = new Date(email.expiresAt.getTime() + 15 * 60 * 1000); // Add 15 minutes
      const updatedEmail = await storage.updateTemporaryEmailExpiry(parseInt(id), newExpiryTime);
      
      res.json(updatedEmail);
    } catch (error: any) {
      res.status(500).json({ message: "Error extending email: " + error.message });
    }
  });

  // Stripe payment route for premium upgrade
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      const { emailId } = req.body;
      
      if (!emailId) {
        return res.status(400).json({ message: "Email ID is required" });
      }
      
      // Get the email details to store in metadata
      const email = await storage.getTemporaryEmailById(emailId);
      if (!email) {
        return res.status(404).json({ message: "Email not found" });
      }
      
      const paymentIntent = await stripe.paymentIntents.create({
        amount: 299, // $2.99 in cents
        currency: "usd",
        metadata: {
          emailId: emailId.toString(),
          emailAddress: email.emailAddress,
          upgrade: "premium",
        },
      });
      
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Process premium upgrade after successful payment
  app.post("/api/upgrade-premium", async (req, res) => {
    try {
      const { paymentIntentId } = req.body;
      
      if (!paymentIntentId) {
        return res.status(400).json({ message: "Payment intent ID is required" });
      }
      
      // Verify payment with Stripe
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
      
      if (paymentIntent.status !== "succeeded") {
        return res.status(400).json({ message: "Payment not successful" });
      }
      
      const emailId = parseInt(paymentIntent.metadata?.emailId || "0");
      const emailAddress = paymentIntent.metadata?.emailAddress;
      
      if (!emailId && !emailAddress) {
        return res.status(400).json({ message: "Invalid email information in payment metadata" });
      }
      
      console.log(`Upgrading email (ID: ${emailId}, Address: ${emailAddress}) to premium...`);
      
      // First try to find by ID, then by email address (in case of server restart)
      let existingEmail = emailId ? await storage.getTemporaryEmailById(emailId) : null;
      
      if (!existingEmail && emailAddress) {
        existingEmail = await storage.getTemporaryEmail(emailAddress);
      }
      
      if (!existingEmail) {
        return res.status(404).json({ 
          message: "Email not found. The email may have expired or been reset. Please generate a new email and try again." 
        });
      }
      
      const updatedEmail = await storage.upgradeToPremium(existingEmail.id);
      console.log(`Email upgraded:`, JSON.stringify(updatedEmail, null, 2));
      
      res.json(updatedEmail);
    } catch (error: any) {
      console.error("Upgrade error:", error);
      res.status(500).json({ message: "Error upgrading to premium: " + error.message });
    }
  });

  // Get inbox messages
  app.get("/api/inbox/:emailId", async (req, res) => {
    try {
      const { emailId } = req.params;
      const messages = await storage.getEmailMessages(parseInt(emailId));
      
      res.json(messages);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching messages: " + error.message });
    }
  });

  // Demo upgrade endpoint for testing
  app.post("/api/demo-upgrade", async (req, res) => {
    try {
      const { emailId } = req.body;
      
      if (!emailId) {
        return res.status(400).json({ message: "Email ID is required" });
      }
      
      console.log(`Demo upgrading email ID ${emailId} to premium...`);
      const updatedEmail = await storage.upgradeToPremium(emailId);
      console.log(`Demo email upgraded:`, JSON.stringify(updatedEmail, null, 2));
      
      res.json(updatedEmail);
    } catch (error: any) {
      console.error("Demo upgrade error:", error);
      res.status(500).json({ message: "Error upgrading to premium: " + error.message });
    }
  });

  // Add demo email to show functionality
  app.post("/api/demo-email/:emailId", async (req, res) => {
    try {
      const { emailId } = req.params;
      const email = await storage.getTemporaryEmailById(parseInt(emailId));
      
      if (!email) {
        return res.status(404).json({ message: "Email not found" });
      }

      // Create a demo email
      const demoMessages = [
        {
          temporaryEmailId: parseInt(emailId),
          fromAddress: "welcome@example.com",
          subject: "Welcome to our service!",
          body: "Thank you for trying our service. This is a demo email to show how your temporary inbox works. You can forward this email to your real address using the forward button."
        },
        {
          temporaryEmailId: parseInt(emailId),
          fromAddress: "noreply@shopping.com",
          subject: "Your order confirmation #12345",
          body: "Your order has been confirmed! Order details: 1x Sample Product - $29.99. Expected delivery: 3-5 business days. Track your order at shopping.com/track"
        },
        {
          temporaryEmailId: parseInt(emailId),
          fromAddress: "newsletter@techblog.com",
          subject: "Weekly Tech Newsletter",
          body: "This week in tech: AI developments, new programming languages, and the latest in cybersecurity. Read more at techblog.com/newsletter"
        }
      ];

      // Add random demo email
      const randomDemo = demoMessages[Math.floor(Math.random() * demoMessages.length)];
      const message = await storage.createEmailMessage(randomDemo);
      
      res.json(message);
    } catch (error: any) {
      res.status(500).json({ message: "Error creating demo email: " + error.message });
    }
  });

  // Forward email
  app.post("/api/forward-email", async (req, res) => {
    try {
      const schema = z.object({
        messageId: z.number(),
        forwardToAddress: z.string().email(),
        note: z.string().optional(),
      });
      
      const { messageId, forwardToAddress, note } = schema.parse(req.body);
      
      const forward = await storage.createEmailForward({
        messageId,
        forwardToAddress,
        note,
      });
      
      // In a real implementation, you would send the actual email here
      // For now, we just record the forward request
      
      res.json({ message: "Email forwarded successfully", forward });
    } catch (error: any) {
      res.status(500).json({ message: "Error forwarding email: " + error.message });
    }
  });

  // Mark message as read
  app.post("/api/mark-read/:messageId", async (req, res) => {
    try {
      const { messageId } = req.params;
      const message = await storage.markEmailAsRead(parseInt(messageId));
      
      res.json(message);
    } catch (error: any) {
      res.status(500).json({ message: "Error marking message as read: " + error.message });
    }
  });

  // Demo premium upgrade endpoint
  app.post("/api/demo-upgrade", async (req, res) => {
    try {
      const { emailId } = req.body;
      
      if (!emailId) {
        return res.status(400).json({ message: "Email ID is required" });
      }

      const email = await storage.getTemporaryEmailById(emailId);
      if (!email) {
        return res.status(404).json({ message: "Email not found" });
      }

      // Upgrade to premium (24 hours from now)
      const newExpiresAt = new Date();
      newExpiresAt.setHours(newExpiresAt.getHours() + 24);
      
      const updatedEmail = await storage.upgradeToPremium(emailId);
      const emailWithNewExpiry = await storage.updateTemporaryEmailExpiry(emailId, newExpiresAt);

      res.json(emailWithNewExpiry);
    } catch (error: any) {
      res.status(500).json({ message: "Error upgrading to premium: " + error.message });
    }
  });

  // Cleanup expired emails (should be called periodically)
  app.post("/api/cleanup-expired", async (req, res) => {
    try {
      await storage.deleteExpiredEmails();
      res.json({ message: "Expired emails cleaned up" });
    } catch (error: any) {
      res.status(500).json({ message: "Error cleaning up expired emails: " + error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
