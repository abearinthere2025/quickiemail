export function generateEmailAddress(): string {
  const randomString = Math.random().toString(36).substring(2, 15);
  const timestamp = Date.now().toString(36);
  return `temp.${randomString}.${timestamp}@quickiemail.com`;
}

export function formatTimeRemaining(seconds: number): string {
  if (seconds <= 0) return "00:00";
  
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  
  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
  return `${minutes}:${secs.toString().padStart(2, '0')}`;
}

export function isEmailExpired(expiresAt: Date): boolean {
  return new Date() > new Date(expiresAt);
}
