import Header from "@/components/header";
import EmailGenerator from "@/components/email-generator";
import Inbox from "@/components/inbox";
import Sidebar from "@/components/sidebar";
import PremiumModal from "@/components/premium-modal";
import ForwardModal from "@/components/forward-modal";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { TemporaryEmail, EmailMessage } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export default function Home() {
  const [currentEmail, setCurrentEmail] = useState<TemporaryEmail | null>(null);
  const [showPremiumModal, setShowPremiumModal] = useState(false);
  const [showForwardModal, setShowForwardModal] = useState(false);
  const [selectedMessage, setSelectedMessage] = useState<EmailMessage | null>(null);
  const [location] = useLocation();

  // Load email from localStorage on mount and handle upgrade success
  useEffect(() => {
    const urlParams = new URLSearchParams(location.split('?')[1] || '');
    const wasUpgraded = urlParams.get('upgraded');
    
    // Load email from localStorage if exists and validate it
    const savedEmail = localStorage.getItem('currentEmail');
    if (savedEmail) {
      try {
        const parsedEmail = JSON.parse(savedEmail);
        // Validate the email still exists on the server
        apiRequest("GET", `/api/email/${parsedEmail.emailAddress}`)
          .then(response => response.json())
          .then(validatedEmail => {
            setCurrentEmail(validatedEmail);
            localStorage.setItem('currentEmail', JSON.stringify(validatedEmail));
          })
          .catch(() => {
            // Email no longer exists, clear localStorage
            localStorage.removeItem('currentEmail');
            setCurrentEmail(null);
          });
      } catch (e) {
        localStorage.removeItem('currentEmail');
        setCurrentEmail(null);
      }
    }
    
    // If user just returned from successful upgrade, refresh email data
    if (wasUpgraded === 'true') {
      const refreshEmailData = async () => {
        try {
          const savedEmail = localStorage.getItem('currentEmail');
          if (savedEmail) {
            const parsedEmail = JSON.parse(savedEmail);
            console.log('Refreshing email data for:', parsedEmail.emailAddress);
            const response = await apiRequest("GET", `/api/email/${parsedEmail.emailAddress}`);
            const updatedEmail = await response.json();
            console.log('Updated email data:', updatedEmail);
            setCurrentEmail(updatedEmail);
            localStorage.setItem('currentEmail', JSON.stringify(updatedEmail));
          }
          
          // Clear the URL parameter
          window.history.replaceState({}, '', '/');
        } catch (error) {
          console.error('Failed to refresh email data:', error);
        }
      };
      
      refreshEmailData();
    }
  }, [location]);

  const handleEmailGenerated = (email: TemporaryEmail) => {
    setCurrentEmail(email);
    localStorage.setItem('currentEmail', JSON.stringify(email));
  };

  const handleForwardEmail = (message: EmailMessage) => {
    setSelectedMessage(message);
    setShowForwardModal(true);
  };

  const handleEmailUpdated = (email: TemporaryEmail) => {
    setCurrentEmail(email);
    localStorage.setItem('currentEmail', JSON.stringify(email));
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header onShowPremium={() => setShowPremiumModal(true)} />
      
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <EmailGenerator 
          onEmailGenerated={handleEmailGenerated}
          currentEmail={currentEmail}
          onEmailUpdated={handleEmailUpdated}
          onShowPremium={() => setShowPremiumModal(true)}
        />
        
        <div className="grid md:grid-cols-3 gap-8 mt-8">
          <div className="md:col-span-2">
            <Inbox 
              currentEmail={currentEmail}
              onForwardEmail={handleForwardEmail}
            />
          </div>
          <div>
            <Sidebar onShowPremium={() => setShowPremiumModal(true)} />
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                    <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-gray-900">Quickiemail</h3>
              </div>
              <p className="text-gray-600 mb-4">
                The fastest way to create temporary email addresses. Protect your privacy and avoid spam with our secure disposable email service.
              </p>
              <div className="flex space-x-4">
                <span className="text-sm text-gray-500">© 2025 Quickiemail. All rights reserved.</span>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">Features</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>15-minute free emails</li>
                <li>24-hour premium access</li>
                <li>Email forwarding</li>
                <li>No registration required</li>
                <li>100% anonymous</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">Legal</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><a href="/privacy" className="hover:text-primary">Privacy Policy</a></li>
                <li><a href="/terms" className="hover:text-primary">Terms of Service</a></li>
                <li><a href="mailto:support@quickiemail.com" className="hover:text-primary">Contact Us</a></li>
                <li><a href="mailto:legal@quickiemail.com" className="hover:text-primary">Legal Inquiries</a></li>
              </ul>
            </div>
          </div>
        </div>
      </footer>

      <PremiumModal 
        isOpen={showPremiumModal}
        onClose={() => setShowPremiumModal(false)}
        currentEmail={currentEmail}
        onEmailUpdated={handleEmailUpdated}
      />

      <ForwardModal
        isOpen={showForwardModal}
        onClose={() => setShowForwardModal(false)}
        message={selectedMessage}
      />
    </div>
  );
}
