import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { useParams, useLocation } from 'wouter';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Crown, Check } from "lucide-react";

// Use fresh API keys
const freshStripeKey = import.meta.env.VITE_STRIPE_PUBLIC_KEY_NEW;
const isValidStripeKey = freshStripeKey && 
  freshStripeKey.startsWith('pk_') && 
  freshStripeKey.length > 50 &&
  !freshStripeKey.includes('*');

const stripePromise = isValidStripeKey 
  ? loadStripe(freshStripeKey)
  : null;

const CheckoutForm = ({ emailId }: { emailId: string }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    if (!stripe || !elements) {
      setIsProcessing(false);
      return;
    }

    const { error, paymentIntent } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/?upgraded=true`,
      },
      redirect: 'if_required',
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
      setIsProcessing(false);
    } else if (paymentIntent && paymentIntent.status === 'succeeded') {
      try {
        const response = await apiRequest("POST", "/api/upgrade-premium", {
          paymentIntentId: paymentIntent.id,
        });
        const upgradedEmail = await response.json();
        
        // Update localStorage with the upgraded email data
        localStorage.setItem('currentEmail', JSON.stringify(upgradedEmail));
        
        toast({
          title: "Payment Successful",
          description: "Your email has been upgraded to premium (24 hours)!",
        });
        
        setLocation("/?upgraded=true");
      } catch (upgradeError: any) {
        console.error("Upgrade error:", upgradeError);
        const errorMessage = upgradeError.message || "Payment succeeded but upgrade failed. Please contact support.";
        toast({
          title: "Upgrade Error",
          description: errorMessage,
          variant: "destructive",
        });
      }
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <Button 
        type="submit" 
        disabled={!stripe || isProcessing}
        className="w-full bg-accent hover:bg-accent/90 text-white"
        size="lg"
      >
        {isProcessing ? (
          <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
        ) : (
          <Crown className="w-4 h-4 mr-2" />
        )}
        {isProcessing ? "Processing..." : "Pay $2.99"}
      </Button>
    </form>
  );
};

export default function Checkout() {
  const { emailId } = useParams<{ emailId: string }>();
  const [, setLocation] = useLocation();
  const [clientSecret, setClientSecret] = useState("");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!emailId) {
      setLocation("/");
      return;
    }

    apiRequest("POST", "/api/create-payment-intent", { emailId: parseInt(emailId) })
      .then((res) => res.json())
      .then((data) => {
        setClientSecret(data.clientSecret);
        setIsLoading(false);
      })
      .catch(() => {
        setLocation("/");
      });
  }, [emailId, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!clientSecret || !stripePromise) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <Crown className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Demo Mode - Free Premium Upgrade</h3>
            <p className="text-gray-600 mb-4">
              Payment processing is currently in demo mode. Click below for a free premium upgrade to test the 24-hour feature.
            </p>
            <Button 
              onClick={async () => {
                try {
                  await apiRequest("POST", "/api/demo-upgrade", { emailId: parseInt(emailId) });
                  // Show success message - in real implementation would show toast
                  alert("Demo upgrade successful! Your email has been upgraded to premium for 24 hours!");
                  setLocation("/?upgraded=true");
                } catch (error) {
                  // Show error message - in real implementation would show toast
                  alert("Upgrade failed. Please try again.");
                }
              }}
              className="w-full bg-yellow-500 hover:bg-yellow-600 text-white mb-3"
              size="lg"
            >
              <Crown className="w-4 h-4 mr-2" />
              Get Free Demo Premium (24 Hours)
            </Button>
            <Button 
              onClick={() => setLocation("/")} 
              variant="outline" 
              className="w-full"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-2xl mx-auto px-4 py-8">
        <Button 
          onClick={() => setLocation("/")} 
          variant="ghost" 
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Button>

        <Card className="mb-6">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
              <Crown className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl">Upgrade to Premium</CardTitle>
            <p className="text-gray-600">Extend your temporary email to 24 hours</p>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 rounded-lg p-4 mb-6">
              <div className="flex justify-between items-center mb-4">
                <span className="text-gray-700 font-medium">Premium Access (24 hours)</span>
                <span className="text-2xl font-bold text-gray-900">$2.99</span>
              </div>
              <div className="space-y-2">
                <div className="flex items-center text-sm text-gray-600">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  24-hour email duration
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Unlimited extensions
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Ad-free experience
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Priority support
                </div>
              </div>
            </div>

            <Elements stripe={stripePromise} options={{ clientSecret }}>
              <CheckoutForm emailId={emailId!} />
            </Elements>
          </CardContent>
        </Card>

        <div className="text-center text-sm text-gray-500">
          <p>Secure payment powered by Stripe</p>
          <p className="mt-1">Your payment information is encrypted and secure</p>
        </div>
      </div>
    </div>
  );
}
