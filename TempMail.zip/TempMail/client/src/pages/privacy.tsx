import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function Privacy() {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <Link href="/">
            <Button variant="outline" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl">Privacy Policy</CardTitle>
            <p className="text-gray-600">Last updated: July 2, 2025</p>
          </CardHeader>
          <CardContent className="prose max-w-none">
            <h2>Information We Collect</h2>
            <p>
              Quickiemail is designed with privacy in mind. We collect minimal information necessary to provide our temporary email service:
            </p>
            <ul>
              <li>Temporary email addresses you generate (automatically deleted after expiration)</li>
              <li>Email messages received at temporary addresses (automatically deleted)</li>
              <li>Payment information for premium upgrades (processed securely by Stripe)</li>
              <li>Basic usage analytics (anonymous)</li>
            </ul>

            <h2>How We Use Your Information</h2>
            <p>We use the collected information solely to:</p>
            <ul>
              <li>Provide and maintain the temporary email service</li>
              <li>Process premium upgrade payments</li>
              <li>Improve our service quality</li>
              <li>Comply with legal obligations</li>
            </ul>

            <h2>Data Retention</h2>
            <p>
              Temporary emails and their messages are automatically deleted when they expire (15 minutes for free accounts, 24 hours for premium). 
              We do not store expired email data.
            </p>

            <h2>Third-Party Services</h2>
            <p>We use the following third-party services:</p>
            <ul>
              <li><strong>Stripe:</strong> For secure payment processing</li>
              <li><strong>Google AdSense:</strong> For displaying advertisements</li>
              <li><strong>Google Analytics:</strong> For anonymous usage statistics</li>
            </ul>

            <h2>Cookies and Tracking</h2>
            <p>
              We use minimal cookies for essential functionality like maintaining your session and preferences. 
              Third-party services may use their own cookies for advertising and analytics.
            </p>

            <h2>Data Security</h2>
            <p>
              We implement appropriate security measures to protect your information. However, no internet transmission 
              is 100% secure, and we cannot guarantee absolute security.
            </p>

            <h2>Your Rights</h2>
            <p>You have the right to:</p>
            <ul>
              <li>Access your personal information</li>
              <li>Request deletion of your data</li>
              <li>Opt out of non-essential cookies</li>
              <li>Contact us with privacy concerns</li>
            </ul>

            <h2>Children's Privacy</h2>
            <p>
              Our service is not intended for children under 13. We do not knowingly collect personal information 
              from children under 13.
            </p>

            <h2>Changes to This Policy</h2>
            <p>
              We may update this privacy policy from time to time. We will notify users of any significant changes 
              by posting the new policy on this page.
            </p>

            <h2>Contact Us</h2>
            <p>
              If you have any questions about this privacy policy, please contact us at privacy@quickiemail.com
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}