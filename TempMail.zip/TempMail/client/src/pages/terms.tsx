import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function Terms() {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <Link href="/">
            <Button variant="outline" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl">Terms of Service</CardTitle>
            <p className="text-gray-600">Last updated: July 2, 2025</p>
          </CardHeader>
          <CardContent className="prose max-w-none">
            <h2>Acceptance of Terms</h2>
            <p>
              By accessing and using Quickiemail, you accept and agree to be bound by the terms and provision of this agreement.
            </p>

            <h2>Service Description</h2>
            <p>
              Quickiemail provides temporary email addresses for legitimate purposes including:
            </p>
            <ul>
              <li>Website registrations and signups</li>
              <li>Software downloads and trials</li>
              <li>Privacy protection from spam</li>
              <li>One-time communications</li>
            </ul>

            <h2>Acceptable Use</h2>
            <p>You agree NOT to use our service for:</p>
            <ul>
              <li>Illegal activities or fraud</li>
              <li>Harassment, abuse, or spam</li>
              <li>Circumventing security measures</li>
              <li>Creating multiple accounts to bypass limits</li>
              <li>Commercial email marketing</li>
              <li>Any activity that violates applicable laws</li>
            </ul>

            <h2>Service Availability</h2>
            <p>
              We strive to maintain 99% uptime but cannot guarantee uninterrupted service. Temporary emails 
              automatically expire (15 minutes free, 24 hours premium) and cannot be recovered after expiration.
            </p>

            <h2>Premium Services</h2>
            <p>
              Premium upgrades extend email duration to 24 hours for $2.99. Payments are processed securely 
              through Stripe. Premium features are non-refundable once activated.
            </p>

            <h2>Privacy and Data</h2>
            <p>
              All temporary emails and messages are automatically deleted upon expiration. We do not store 
              expired data. See our Privacy Policy for detailed information handling practices.
            </p>

            <h2>Intellectual Property</h2>
            <p>
              The Quickiemail service, including its design, functionality, and content, is protected by 
              copyright and other intellectual property laws.
            </p>

            <h2>Disclaimers</h2>
            <p>
              The service is provided "as is" without warranties of any kind. We are not responsible for:
            </p>
            <ul>
              <li>Loss of temporary email access</li>
              <li>Missed emails due to service interruptions</li>
              <li>Content of emails received at temporary addresses</li>
              <li>Third-party actions using our service</li>
            </ul>

            <h2>Limitation of Liability</h2>
            <p>
              In no event shall Quickiemail be liable for any indirect, incidental, special, consequential, 
              or punitive damages resulting from your use of the service.
            </p>

            <h2>Account Termination</h2>
            <p>
              We reserve the right to terminate or suspend access to our service immediately, without prior 
              notice, for any violation of these terms.
            </p>

            <h2>Changes to Terms</h2>
            <p>
              We reserve the right to modify these terms at any time. Continued use of the service after 
              changes constitutes acceptance of the new terms.
            </p>

            <h2>Governing Law</h2>
            <p>
              These terms shall be governed by and construed in accordance with applicable laws, without 
              regard to conflict of law provisions.
            </p>

            <h2>Contact Information</h2>
            <p>
              For questions about these terms, please contact us at legal@quickiemail.com
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}