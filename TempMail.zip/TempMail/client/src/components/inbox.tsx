import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TemporaryEmail, EmailMessage } from "@shared/schema";
import { Inbox as InboxIcon, RefreshCw, Share, Mail } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface InboxProps {
  currentEmail: TemporaryEmail | null;
  onForwardEmail: (message: EmailMessage) => void;
}

export default function Inbox({ currentEmail, onForwardEmail }: InboxProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const { data: messages = [], refetch, isLoading } = useQuery<EmailMessage[]>({
    queryKey: ["/api/inbox", currentEmail?.id],
    enabled: !!currentEmail?.id,
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const demoEmailMutation = useMutation({
    mutationFn: () => apiRequest("POST", `/api/demo-email/${currentEmail?.id}`).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inbox", currentEmail?.id] });
      toast({
        title: "Demo Email Added!",
        description: "A sample email has been added to your inbox.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add demo email",
        variant: "destructive",
      });
    },
  });

  if (!currentEmail) {
    return null;
  }

  const handleRefresh = () => {
    refetch();
  };

  const handleDemoEmail = () => {
    demoEmailMutation.mutate();
  };

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <InboxIcon className="w-5 h-5 text-primary" />
            <span>Inbox</span>
          </CardTitle>
          <Button
            onClick={handleRefresh}
            variant="outline"
            size="sm"
            disabled={isLoading}
          >
            <RefreshCw className={`w-4 h-4 mr-1 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {messages.length > 0 ? (
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <h4 className="font-medium text-gray-900">{message.subject}</h4>
                      {!message.isRead && (
                        <Badge variant="default" className="text-xs">
                          New
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{message.fromAddress}</p>
                    <p className="text-sm text-gray-700 line-clamp-2">{message.body}</p>
                  </div>
                  <div className="flex items-center space-x-2 ml-4">
                    <span className="text-xs text-gray-500">
                      {message.receivedAt ? formatDistanceToNow(new Date(message.receivedAt), { addSuffix: true }) : ''}
                    </span>
                    <Button
                      onClick={() => onForwardEmail(message)}
                      variant="ghost"
                      size="sm"
                      title="Forward email"
                    >
                      <Share className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Mail className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No emails yet</h3>
            <p className="text-gray-600 mb-4">
              Emails sent to your temporary address will appear here
            </p>
            <Button
              onClick={handleDemoEmail}
              variant="outline"
              className="text-primary border-primary hover:bg-primary hover:text-white"
            >
              Add Demo Email
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
