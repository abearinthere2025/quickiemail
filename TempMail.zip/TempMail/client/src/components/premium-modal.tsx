import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { TemporaryEmail } from "@shared/schema";
import { Crown, Check } from "lucide-react";

interface PremiumModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentEmail: TemporaryEmail | null;
  onEmailUpdated: (email: TemporaryEmail) => void;
}

export default function PremiumModal({ 
  isOpen, 
  onClose, 
  currentEmail 
}: PremiumModalProps) {
  const [, setLocation] = useLocation();

  const handleUpgrade = () => {
    if (!currentEmail) return;
    onClose();
    setLocation(`/checkout/${currentEmail.id}`);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md" aria-describedby="premium-description">
        <DialogHeader className="text-center">
          <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
            <Crown className="w-8 h-8 text-white" />
          </div>
          <DialogTitle className="text-2xl">Upgrade to Premium</DialogTitle>
          <DialogDescription id="premium-description" className="text-gray-600">
            Extend your email to 24 hours with premium features
          </DialogDescription>
        </DialogHeader>

        <div className="bg-gray-50 rounded-lg p-4 mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-gray-700">Premium Access (24 hours)</span>
            <span className="font-semibold text-gray-900">$2.99</span>
          </div>
          <div className="space-y-2">
            <div className="flex items-center text-sm text-gray-600">
              <Check className="w-4 h-4 text-green-500 mr-2" />
              24-hour email duration
            </div>
            <div className="flex items-center text-sm text-gray-600">
              <Check className="w-4 h-4 text-green-500 mr-2" />
              Unlimited extensions
            </div>
            <div className="flex items-center text-sm text-gray-600">
              <Check className="w-4 h-4 text-green-500 mr-2" />
              Ad-free experience
            </div>
          </div>
        </div>

        <div className="flex space-x-3">
          <Button
            onClick={onClose}
            variant="outline"
            className="flex-1"
          >
            Cancel
          </Button>
          <Button
            onClick={handleUpgrade}
            className="flex-1 bg-accent hover:bg-accent/90 text-white"
            disabled={!currentEmail}
          >
            <Crown className="w-4 h-4 mr-2" />
            Upgrade Now
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
