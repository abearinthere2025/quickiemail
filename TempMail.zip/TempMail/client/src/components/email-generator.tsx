import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { TemporaryEmail } from "@shared/schema";
import { Copy, Sparkles, Crown, Plus } from "lucide-react";
import Timer from "./timer";

interface EmailGeneratorProps {
  onEmailGenerated: (email: TemporaryEmail) => void;
  currentEmail: TemporaryEmail | null;
  onEmailUpdated: (email: TemporaryEmail) => void;
  onShowPremium: () => void;
}

export default function EmailGenerator({ 
  onEmailGenerated, 
  currentEmail, 
  onEmailUpdated,
  onShowPremium 
}: EmailGeneratorProps) {
  const { toast } = useToast();

  const generateEmailMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/generate-email").then(res => res.json()),
    onSuccess: (email: TemporaryEmail) => {
      onEmailGenerated(email);
      toast({
        title: "Success!",
        description: "Temporary email created successfully!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to generate email",
        variant: "destructive",
      });
    },
  });

  const extendEmailMutation = useMutation({
    mutationFn: () => apiRequest("POST", `/api/extend-email/${currentEmail?.id}`).then(res => res.json()),
    onSuccess: (email: TemporaryEmail) => {
      onEmailUpdated(email);
      toast({
        title: "Success!",
        description: "Email extended by 15 minutes!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to extend email",
        variant: "destructive",
      });
    },
  });

  const copyToClipboard = async () => {
    if (!currentEmail) return;
    
    try {
      await navigator.clipboard.writeText(currentEmail.emailAddress);
      toast({
        title: "Copied!",
        description: "Email address copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy email address",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="mb-8">
      <Card className="shadow-lg">
        <CardContent className="p-6 md:p-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Get Your Temporary Email
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Create a disposable email address that lasts 15 minutes. Perfect for signups, downloads, and protecting your privacy from spam.
            </p>
            <div className="flex justify-center items-center space-x-6 mt-6 text-sm text-gray-500">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>No Registration</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span>Instant Access</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                <span>100% Anonymous</span>
              </div>
            </div>
          </div>

          <div className="max-w-2xl mx-auto">
            {currentEmail ? (
              <div className="bg-gray-50 rounded-lg p-6 mb-6 animate-fadeIn">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex-1">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Your Temporary Email
                    </label>
                    <div className="flex items-center space-x-3">
                      <Input
                        value={currentEmail.emailAddress}
                        readOnly
                        className="flex-1 font-mono text-sm bg-white"
                      />
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={copyToClipboard}
                        title="Copy to clipboard"
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          localStorage.removeItem('currentEmail');
                          onEmailUpdated(null as any);
                          window.location.reload();
                        }}
                        title="Start over with new email"
                      >
                        Start Over
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-lg p-4 mb-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Timer 
                        expiresAt={currentEmail.expiresAt} 
                        isPremium={!!currentEmail.isPremium}
                      />
                    </div>
                    <Button
                      onClick={() => extendEmailMutation.mutate()}
                      disabled={extendEmailMutation.isPending}
                      className="bg-green-600 hover:bg-green-700 text-white"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      +15 min
                    </Button>
                  </div>
                </div>

                {!currentEmail.isPremium && (
                  <div className="bg-gradient-to-r from-accent to-orange-600 rounded-lg p-4 text-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold mb-1">Upgrade to Premium</h3>
                        <p className="text-sm opacity-90">Get 24 hours access for just $2.99</p>
                      </div>
                      <Button
                        onClick={onShowPremium}
                        className="bg-white text-accent hover:bg-gray-100"
                      >
                        <Crown className="w-4 h-4 mr-2" />
                        Upgrade
                      </Button>
                    </div>
                  </div>
                )}

                {currentEmail.isPremium && (
                  <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-4 text-white">
                    <div className="flex items-center justify-center space-x-2">
                      <Crown className="w-5 h-5" />
                      <span className="font-semibold">Premium Active</span>
                      <Badge variant="secondary" className="bg-white/20 text-white">
                        24 Hours
                      </Badge>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center">
                <Button
                  onClick={() => generateEmailMutation.mutate()}
                  disabled={generateEmailMutation.isPending}
                  size="lg"
                  className="bg-primary hover:bg-primary/90 text-white px-8 py-4 text-lg shadow-lg transform hover:scale-[1.02] transition-all"
                >
                  {generateEmailMutation.isPending ? (
                    <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full mr-3" />
                  ) : (
                    <Sparkles className="w-5 h-5 mr-3" />
                  )}
                  Generate Temporary Email
                </Button>
                <p className="text-sm text-gray-500 mt-3">
                  Free • No registration required • Expires in 15 minutes
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
