import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, Clock, Share, Crown, Check } from "lucide-react";

interface SidebarProps {
  onShowPremium: () => void;
}

export default function Sidebar({ onShowPremium }: SidebarProps) {
  return (
    <div className="space-y-6">
      {/* Google AdSense */}
      <Card className="shadow-lg">
        <CardContent className="p-4">
          <div className="text-center">
            <p className="text-xs text-gray-500 mb-3">Advertisement</p>
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg p-6 border border-gray-200 min-h-[250px] flex flex-col justify-center items-center">
              <div className="text-4xl mb-4">🚀</div>
              <h3 className="font-semibold text-gray-800 mb-2">Boost Your Productivity</h3>
              <p className="text-sm text-gray-600 mb-4 text-center">
                Premium tools for developers and professionals
              </p>
              <div className="bg-blue-500 text-white px-4 py-2 rounded-md text-sm font-medium">
                Learn More
              </div>
            </div>
            <script 
              async 
              src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"
            ></script>
            <ins 
              className="adsbygoogle"
              style={{ display: 'block' }}
              data-ad-client="ca-pub-6007363543206285"
              data-ad-slot="1234567890"
              data-ad-format="auto"
              data-full-width-responsive="true"
            ></ins>
            <script>
              (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
          </div>
        </CardContent>
      </Card>

      {/* Features Card */}
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-lg">Why Quickiemail?</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-start space-x-3">
              <Shield className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
              <div>
                <h4 className="font-medium text-gray-900">Privacy Protected</h4>
                <p className="text-sm text-gray-600">Keep your real email safe from spam</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <Clock className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
              <div>
                <h4 className="font-medium text-gray-900">Quick & Easy</h4>
                <p className="text-sm text-gray-600">Instant temporary email generation</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <Share className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
              <div>
                <h4 className="font-medium text-gray-900">Email Forwarding</h4>
                <p className="text-sm text-gray-600">Forward important emails to your real inbox</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Premium Features */}
      <Card className="shadow-lg bg-gradient-to-br from-accent to-orange-600 text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Crown className="w-5 h-5" />
            <span>Premium Features</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 mb-6">
            <div className="flex items-center space-x-2">
              <Check className="w-4 h-4 text-white flex-shrink-0" />
              <span className="text-sm">24-hour email duration</span>
            </div>
            <div className="flex items-center space-x-2">
              <Check className="w-4 h-4 text-white flex-shrink-0" />
              <span className="text-sm">Unlimited extensions</span>
            </div>
            <div className="flex items-center space-x-2">
              <Check className="w-4 h-4 text-white flex-shrink-0" />
              <span className="text-sm">Priority support</span>
            </div>
            <div className="flex items-center space-x-2">
              <Check className="w-4 h-4 text-white flex-shrink-0" />
              <span className="text-sm">No advertisements</span>
            </div>
          </div>
          <Button
            onClick={onShowPremium}
            className="w-full bg-white text-accent hover:bg-gray-100 font-semibold"
          >
            Upgrade for $2.99
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
