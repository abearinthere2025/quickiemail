import { useTimer } from "@/hooks/use-timer";
import { Clock } from "lucide-react";

interface TimerProps {
  expiresAt: Date;
  isPremium?: boolean;
}

export default function Timer({ expiresAt, isPremium }: TimerProps) {
  const { timeLeft, isExpired } = useTimer(expiresAt);

  const formatTime = (seconds: number) => {
    if (seconds <= 0) return "00:00";
    
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex items-center space-x-3">
      <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
        isExpired ? 'bg-red-500' : isPremium ? 'bg-green-500' : 'bg-primary'
      }`}>
        <Clock className="w-6 h-6 text-white" />
      </div>
      <div>
        <p className="text-sm text-gray-600">
          {isExpired ? 'Expired' : 'Time Remaining'}
        </p>
        <p className={`text-2xl font-bold ${
          isExpired ? 'text-red-600' : 'text-gray-900'
        }`}>
          {isExpired ? 'EXPIRED' : formatTime(timeLeft)}
        </p>
      </div>
    </div>
  );
}
