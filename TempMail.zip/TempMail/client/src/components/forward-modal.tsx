import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { EmailMessage } from "@shared/schema";
import { Share, X } from "lucide-react";
import { useState } from "react";

interface ForwardModalProps {
  isOpen: boolean;
  onClose: () => void;
  message: EmailMessage | null;
}

export default function ForwardModal({ isOpen, onClose, message }: ForwardModalProps) {
  const { toast } = useToast();
  const [forwardEmail, setForwardEmail] = useState("");
  const [note, setNote] = useState("");

  const forwardMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/forward-email", {
      messageId: message?.id,
      forwardToAddress: forwardEmail,
      note: note || undefined,
    }),
    onSuccess: () => {
      toast({
        title: "Success!",
        description: "Email forwarded successfully!",
      });
      onClose();
      setForwardEmail("");
      setNote("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to forward email",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message || !forwardEmail) return;
    forwardMutation.mutate();
  };

  const handleClose = () => {
    onClose();
    setForwardEmail("");
    setNote("");
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md" aria-describedby="forward-description">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center space-x-2">
              <Share className="w-5 h-5" />
              <span>Forward Email</span>
            </DialogTitle>
            <Button
              onClick={handleClose}
              variant="ghost"
              size="sm"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
          <DialogDescription id="forward-description" className="text-gray-600">
            Forward this email to your personal email address
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="forwardEmail">Forward to:</Label>
            <Input
              id="forwardEmail"
              type="email"
              value={forwardEmail}
              onChange={(e) => setForwardEmail(e.target.value)}
              placeholder="your-email@example.com"
              required
            />
          </div>
          
          <div>
            <Label htmlFor="note">Add note (optional):</Label>
            <Textarea
              id="note"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Add a personal note..."
              rows={3}
            />
          </div>

          <div className="flex space-x-3">
            <Button
              type="button"
              onClick={handleClose}
              variant="outline"
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={forwardMutation.isPending || !forwardEmail}
              className="flex-1 bg-primary hover:bg-primary/90"
            >
              {forwardMutation.isPending ? (
                <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
              ) : (
                <Share className="w-4 h-4 mr-2" />
              )}
              Forward
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
