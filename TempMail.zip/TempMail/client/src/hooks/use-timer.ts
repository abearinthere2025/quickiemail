import { useState, useEffect } from "react";

export function useTimer(expiresAt: Date) {
  const [timeLeft, setTimeLeft] = useState(0);
  const [isExpired, setIsExpired] = useState(false);

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date().getTime();
      const expiry = new Date(expiresAt).getTime();
      const difference = expiry - now;

      if (difference <= 0) {
        setTimeLeft(0);
        setIsExpired(true);
        return 0;
      }

      const seconds = Math.floor(difference / 1000);
      setTimeLeft(seconds);
      setIsExpired(false);
      return seconds;
    };

    // Initial calculation
    calculateTimeLeft();

    // Set up interval to update every second
    const interval = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(interval);
  }, [expiresAt]);

  return { timeLeft, isExpired };
}
