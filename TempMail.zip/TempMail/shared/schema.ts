import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
});

export const temporaryEmails = pgTable("temporary_emails", {
  id: serial("id").primaryKey(),
  emailAddress: text("email_address").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  isPremium: boolean("is_premium").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const emailMessages = pgTable("email_messages", {
  id: serial("id").primaryKey(),
  temporaryEmailId: integer("temporary_email_id").references(() => temporaryEmails.id),
  fromAddress: text("from_address").notNull(),
  subject: text("subject").notNull(),
  body: text("body").notNull(),
  receivedAt: timestamp("received_at").defaultNow(),
  isRead: boolean("is_read").default(false),
});

export const emailForwards = pgTable("email_forwards", {
  id: serial("id").primaryKey(),
  messageId: integer("message_id").references(() => emailMessages.id),
  forwardToAddress: text("forward_to_address").notNull(),
  note: text("note"),
  forwardedAt: timestamp("forwarded_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertTemporaryEmailSchema = createInsertSchema(temporaryEmails).omit({
  id: true,
  createdAt: true,
});

export const insertEmailMessageSchema = createInsertSchema(emailMessages).omit({
  id: true,
  receivedAt: true,
  isRead: true,
});

export const insertEmailForwardSchema = createInsertSchema(emailForwards).omit({
  id: true,
  forwardedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type TemporaryEmail = typeof temporaryEmails.$inferSelect;
export type InsertTemporaryEmail = z.infer<typeof insertTemporaryEmailSchema>;
export type EmailMessage = typeof emailMessages.$inferSelect;
export type InsertEmailMessage = z.infer<typeof insertEmailMessageSchema>;
export type EmailForward = typeof emailForwards.$inferSelect;
export type InsertEmailForward = z.infer<typeof insertEmailForwardSchema>;
